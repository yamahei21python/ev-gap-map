CREATE TABLE stations (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            address TEXT NOT NULL,
            prefecture TEXT,
            latitude REAL,
            longitude REAL,
            business_hours TEXT,
            closed_days TEXT,
            url TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        , geocoding_status INTEGER DEFAULT 0);
CREATE TABLE chargers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            station_id TEXT NOT NULL,
            charger_type TEXT NOT NULL,
            count INTEGER DEFAULT 1,
            power_kw REAL,
            max_ampere REAL,
            is_paid BOOLEAN,
            parking_fee TEXT,
            FOREIGN KEY (station_id) REFERENCES stations(id)
        );
CREATE TABLE sqlite_sequence(name,seq);
CREATE TABLE scrape_progress (
            prefecture_code TEXT PRIMARY KEY,
            last_page INTEGER DEFAULT 0,
            total_pages INTEGER,
            completed BOOLEAN DEFAULT 0,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
CREATE TABLE mesh_population (
            mesh_code TEXT PRIMARY KEY,
            population INTEGER NOT NULL,
            lat_min REAL,
            lon_min REAL,
            lat_max REAL,
            lon_max REAL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
CREATE INDEX idx_stations_prefecture ON stations(prefecture);
CREATE INDEX idx_chargers_station_id ON chargers(station_id);
CREATE INDEX idx_chargers_type ON chargers(charger_type);
CREATE INDEX idx_mesh_population ON mesh_population(population);
